# ayunEaglerConfig
Eaglercraft client configuration utility.

Utilizes:
- a slightly modified version of [powernbt-js](https://github.com/DPOH-VAR/powernbt-js)
- [long.js](https://github.com/dcodeIO/Long.js)
- [json-editor](https://github.com/json-editor/json-editor)
- [Nunito Font](https://fonts.google.com/specimen/Nunito)
